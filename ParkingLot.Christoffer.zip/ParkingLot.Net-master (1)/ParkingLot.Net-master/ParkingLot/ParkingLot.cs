﻿using System;
using System.Collections.Generic;

namespace ParkingLot
{
    public class ParkingLot : IParkingLot
    {
        private List<string> checkedInCars = new List<string>();
        private Dictionary<string, decimal> payment = new Dictionary <string, decimal>();
        public int Fee { get; set; }

        public void BeginCheckout(string licensePlate)
        {
            if (checkedInCars.Contains(licensePlate))
            {
                checkedInCars.Remove(licensePlate);
                payment.Add(licensePlate, 40m);
            }
            else
            {
                Error("Du skal lige tjekke ind min ven");
            }
        }

        public void Checkin(string licensePlate)
        {
            if (checkedInCars.Contains(licensePlate))
            {
                Error("Car already checked in");
            }
            checkedInCars.Add(licensePlate);
            Gates.OpenEntranceGate();
        }

        public decimal GetRemainingFee(string licensePlate)
        {
            return payment.GetValueOrDefault(licensePlate, 0);
        }

        public void Leave(string licensePlate)
        {
            if (payment.ContainsKey(licensePlate))
            {
                if (payment[licensePlate] == 0m || payment[licensePlate] < 0m)
                {
                    Console.WriteLine("{0} kroner igen", payment[licensePlate]);
                    payment.Remove(licensePlate);
                    Gates.OpenExitGate();
                }
                else
                {
                    Error("WOW WOW husk lige at betale");
                }
            }
            else
            {
                Error("prøver du at flyve uden at betale min ven?");
            }
        }


        public void Pay(string licensePlate, decimal amount)
        {
            if(payment.ContainsKey(licensePlate))
            {
                if(amount > 0)
                {
                    payment[licensePlate] -= amount;
                }
                else
                {
                    Error("Prøver du at stjæle min ven");
                }
            }
            else
            {
                Error("Du må da gerne betale under bordet");
            }
        }
             

        void Error(string msg)
        {
            throw new InvalidOperationException(msg);
        }
    }
}
